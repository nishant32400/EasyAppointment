# Doctor-Appointment
Developed using HTML5, CSS3, JavaScript, PHP 5.0+,AJAX ,MySql.
